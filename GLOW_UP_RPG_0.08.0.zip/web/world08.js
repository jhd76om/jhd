/* GLOW UP RPG V0.08 — Real Life World; uses the existing state, activity forms, XP and backups. */
(()=>{'use strict';
const g=window.glowBridge;if(!g)return;
const safe=x=>g.ESC(String(x??''));
const num=(v,d=0)=>Number(v||0).toLocaleString('en-US',{maximumFractionDigits:d,minimumFractionDigits:d});
const a=v=>Array.isArray(v)?v:[];
const state=()=>g.get();
const clock=()=>new Intl.DateTimeFormat('ar-OM',{timeZone:'Asia/Muscat',hour:'numeric',minute:'2-digit',hour12:true}).format(new Date());
const omanHour=()=>Number(new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Muscat',hour:'2-digit',hourCycle:'h23'}).format(new Date()));
const groups=[['home','🏠 المنزل'],['uni','🎓 الجامعة'],['gym','🏋️ النادي'],['car','🚗 السيارة'],['city','🌆 المدينة']];
const scenes=[];
function add(group,id,title,img,hot=[],original=''){scenes.push({group,id,title,img,hot,original});}
const scene=(title,id,x,y)=>({title,kind:'scene',id,x,y});
const action=(title,id,x,y)=>({title,kind:'action',id,x,y});
const view=(title,id,x,y)=>({title,kind:'view',id,x,y});
// Every interactive place uses photo hotspots + accessible buttons; locations in the RPG are simulations only.
add('home','home_exterior','واجهة المنزل','home_exterior',[scene('🚪 المدخل','home_entrance',51,66),scene('🌳 الحديقة','home_garden',14,76),scene('🚘 المرآب','home_garage',85,68)],'entrance');
add('home','home_entrance','مدخل المنزل','home_entrance',[scene('🛏️ غرفة النوم','home_bedroom',39,51),scene('🛋️ الصالة','home_living',78,68),scene('🍳 المطبخ','home_kitchen',12,67)],'entrance');
add('home','home_bedroom','غرفة النوم','home_bedroom',[action('😴 النوم','fullSleep',28,68),scene('💻 المكتب','home_desk',77,56),scene('👔 الخزانة','home_wardrobe',85,36)],'bedroom');
add('home','home_night','غرفة النوم ليلًا','home_night',[action('🌙 النوم','fullSleep',32,66),scene('☀️ إضاءة النهار','home_bedroom',80,28)],'bed');
add('home','home_desk','المكتب الشخصي','home_desk',[action('📚 مذاكرة','study',44,58),action('🎬 صناعة محتوى','creator',78,58),action('📖 الكتب','fullBooks',19,65)],'desk');
add('home','home_wardrobe','خزانة الملابس','home_wardrobe',[action('👔 سجل الملابس','fullWardrobe',45,58),action('✅ ترتيب','organize',80,67)],'wardrobe');
add('home','home_kitchen','المطبخ','home_kitchen',[action('🍽️ تسجيل وجبة','fullFood',56,62),action('💧 ماء','water',20,49),scene('🍴 طاولة الطعام','home_dining',83,78)],'kitchen');
add('home','home_dining','طاولة الطعام','home_dining',[action('🔥 السعرات','fullFood',46,60),action('💧 الماء','water',78,62)],'kitchen');
add('home','home_living','غرفة المعيشة','home_living',[action('📺 الترفيه','fullTV',65,52),view('📅 التقويم','phone',19,63)],'living');
add('home','home_bathroom','الحمام','home_bathroom',[action('🪥 العناية','care',75,54),action('📋 الروتين','routine',19,55)],'bathroom');
add('home','home_garage','مرآب المنزل','home_garage',[scene('🚗 سيارتي','car_exterior',50,61),view('🔧 متابعة السيارة','vehicle',82,49)],'garage');
add('home','home_garden','الحديقة الخارجية','home_garden',[scene('🏠 العودة للمنزل','home_exterior',65,64),action('📋 روتين اليوم','routine',22,67)],'entrance');
add('uni','squ_gate','بوابة جامعة السلطان قابوس','squ_gate',[scene('🏛️ الحرم الجامعي','squ_campus',50,57),scene('🚘 المواقف','squ_parking',82,66)],'campus');
add('uni','squ_campus','الحرم الجامعي','squ_campus',[scene('🏫 كلية الآداب','squ_arts',51,48),scene('📚 المكتبة','squ_library',78,58),scene('☕ كافتيريا','squ_cafe',23,62)],'campus');
add('uni','squ_arts','كلية الآداب والعلوم الاجتماعية','squ_arts',[scene('📖 قاعة المحاضرات','squ_lecture',60,56),view('🎓 نظام الدراسة','university',14,58)],'university');
add('uni','squ_lecture','قاعة المحاضرات','squ_lecture',[action('📓 تسجيل حضور','lecture',68,58),action('📚 جلسة مذاكرة','study',31,74)],'lecturehall');
add('uni','squ_library','المكتبة الرئيسية','squ_library',[scene('💻 طاولة المذاكرة','squ_study',52,70),action('📖 سجل القراءة','fullBooks',21,53)],'unilibrary');
add('uni','squ_study','طاولة المذاكرة بالمكتبة','squ_study',[action('⏱️ بدء دراسة','study',53,51),action('📖 الكتب','fullBooks',17,67),view('📝 المهام','tasks',82,66)],'unilibrary');
add('uni','squ_cafe','كافتيريا الجامعة','squ_cafe',[action('🥗 وجبة','fullFood',20,53),scene('📖 المحاضرات','squ_lecture',81,62)],'campus');
add('uni','squ_parking','مواقف الجامعة','squ_parking',[scene('🚙 سيارة هوندا','car_exterior',20,58),scene('🏛️ إلى الجامعة','squ_gate',71,56)],'garage');
add('gym','gym_entrance','مدخل النادي الرياضي','gym_entrance',[scene('🏋️ الأجهزة','gym_machines',57,61),scene('🚿 غرف الملابس','gym_lockers',88,66)],'gym');
add('gym','gym_machines','صالة أجهزة التمارين','gym_machines',[action('🏋️ تسجيل الجولات','evoGym',46,52),scene('💪 أوزان حرة','gym_dumbbells',15,69),scene('🏃 الكارديو','gym_cardio',84,60)],'gym');
add('gym','gym_dumbbells','منطقة الدمبل والأوزان الحرة','gym_dumbbells',[action('💪 سجل تمرين','evoGym',49,58),action('📈 برنامجي','fullGym',18,64)],'gym');
add('gym','gym_cardio','أجهزة الكارديو','gym_cardio',[action('⏱️ تسجيل جلسة','gymSession',23,54),action('💧 شرب ماء','water',77,65)],'gym');
add('gym','gym_lockers','غرفة تبديل الملابس','gym_lockers',[action('👕 الملابس','fullWardrobe',17,54),action('🧴 العناية','care',82,59)],'gym');
add('car','car_exterior','هوندا أكورد سبورت 2.0 تيربو — أسود','car_exterior',[scene('🚘 مقصورة القيادة','car_cockpit',42,50),view('🔧 سجل المركبة','vehicle',79,68)],'garage');
add('car','car_cockpit','مقصورة القيادة — Honda Accord','car_cockpit',[scene('🛣️ قيادة افتراضية','car_drive',54,32),view('📅 صيانة السيارة','vehicle',86,61)],'garage');
add('car','car_drive','الانطلاق والتنقل','car_drive',[scene('⛽ محطة وقود','car_fuel',83,53),scene('🗺️ مسقط','highway',39,43)],'garage');
add('car','car_fuel','محطة وقود في عُمان','car_fuel',[view('💰 تسجيل الوقود','vehicle',79,53),scene('🧽 المغسلة','car_wash',35,58)],'garage');
add('car','car_wash','مغسلة السيارات','car_wash',[view('📝 سجل العناية','vehicle',19,57),scene('🚗 العودة للسيارة','car_exterior',72,59)],'garage');
add('city','street','شارع سكني عُماني','street',[scene('🛣️ طريق مسقط','highway',49,60),scene('🏠 المنزل','home_exterior',18,68)],'entrance');
add('city','highway','الطريق السريع — مسقط','highway',[scene('🛍️ مركز تجاري','mall',75,56),scene('☕ المقهى','cafe',21,61)],'garage');
add('city','mall','مركز تجاري','mall',[scene('👕 متجر ملابس','clothes_store',17,62),scene('📚 متجر كتب','bookstore',79,59)],'garage');
add('city','clothes_store','متجر الملابس','clothes_store',[action('👕 الخزانة والمشتريات','fullWardrobe',44,56),action('💸 تسجيل مصروف','expense',78,70)],'wardrobe');
add('city','cafe','مقهى هادئ','cafe',[action('☕ تسجيل وجبة','fullFood',78,54),action('📖 دراسة','study',30,74)],'unilibrary');
add('city','bookstore','مكتبة بيع الكتب','bookstore',[action('📚 إضافة كتاب','fullBooks',52,63),action('💰 مصروف','expense',83,57)],'books');
const uiScreens=[['ui_phone','الهاتف الافتراضي'],['ui_desktop','سطح المكتب'],['ui_map','الخريطة التصميمية'],['ui_profile','ملف الشخصية'],['ui_achievements','الإنجازات'],['ui_calendar','التقويم'],['ui_quests','المهمات'],['ui_loading','شاشة التحميل']];
const mapId=new Map(scenes.map(s=>[s.id,s]));
let active='home_bedroom',tab='scene',catalogGroup='all',search='',activeUi=0,gameOpen=false;
let football={loading:false,error:null,matches:[],last:0};
const q=(sel,root=document)=>root.querySelector(sel);
function data(){const s=state();if(!s.world08||typeof s.world08!=='object')s.world08={last:'home_bedroom',notes:{},favs:['home_bedroom','squ_campus','gym_entrance']};const o=s.world08;
 if(!o.notes||typeof o.notes!=='object')o.notes={};if(!Array.isArray(o.favs))o.favs=[];return o;}
function level(x){let lvl=1,n=Number(x)||0;while(lvl<100){const goal=100+25*(lvl-1)+5*(lvl-1)**2;if(n<goal)return{level:lvl,remain:n,goal};n-=goal;lvl++;}return{level:lvl,remain:0,goal:0};}
function today(){return g.today()}
function metrics(){const s=state(),day=today(),ex=s.expansion05||{},ev=s.evolution061||{},meals=a(ex.foods).filter(x=>x.day===day);
 const sum=k=>meals.reduce((acc,v)=>acc+(Number(v[k])||0),0),w=a(s.waterEntries).filter(x=>x.day===day).reduce((acc,v)=>acc+(Number(v.ml)||0),0);
 const study=a(s.activities).filter(v=>v.day===day&&['study','lecture'].includes(v.sessionType)).reduce((acc,v)=>acc+(Number(v.min)||0),0);
 const gy=a(ex.gymSets).filter(x=>x.day===day);const weight=a(ex.weight).filter(x=>Number.isFinite(Number(x.kg))).at(-1);
 const expenses=a(s.transactions).filter(x=>x.type==='expense'&&String(x.date||'').slice(0,10)===day).reduce((acc,v)=>acc+(Number(v.amount)||0),0);
 return {xp:s.xp||0,lvl:level(s.xp),weight:weight?.kg??null,goalWeight:ev.targets?.weight??55,calories:sum('kcal'),protein:sum('protein'),carbs:sum('carbs'),fat:sum('fat'),calorieGoal:ev.targets?.kcal??2500,water:w,hydrationGoal:s.hydrationGoal||2000,study,gym:gy.length,expense:expenses,quests:a(s.quests).filter(x=>!x.done).length,acts:a(s.activities).filter(x=>x.day===day&&x.type!=='achievement').length};}
const path=id=>'assets/world08/'+id+'.webp';
function sceneGo(id){if(!mapId.has(id))return;active=id;tab='scene';data().last=id;g.save();render();}
function toggleFav(id){let o=data(),i=o.favs.indexOf(id);if(i<0)o.favs.push(id);else o.favs.splice(i,1);g.save();render();}
function openWorld(){const o=data();active=mapId.has(o.last)?o.last:'home_bedroom';gameOpen=true;tab='scene';const root=q('#v08-shell');root.classList.add('v08-open');document.body.style.overflow='hidden';render();root.focus();}
function closeWorld(){gameOpen=false;q('#v08-shell')?.classList.remove('v08-open');document.body.style.overflow='';}
function displayTab(id){tab=id;render();}
function launch(id){if(id==='windowsCenter'){const btn=document.querySelector('[data-win-action="center"]');if(btn){btn.click();return;}}const act=window.glowExtraActions?.[id];if(typeof act==='function'){act();return;}
 const b=document.querySelector(`[data-action="${id}"]`);if(b && !b.closest('#v08-shell')){b.click();return;}g.toast('هذا القسم غير متاح في النسخة الحالية');}
function handle(kind,id){if(kind==='scene'){sceneGo(id);return;}if(kind==='view'){displayTab(id);return;}if(kind==='action'){launch(id);return;}}
function statCard(title,val,unit=''){return `<div class="v08-metric"><small>${safe(title)}</small><b>${safe(val)} <small>${safe(unit)}</small></b></div>`;}
function mainSide(){const m=metrics();return `<div class="v08-sidecard"><h3>⭐ شخصيتك اليوم</h3><div class="v08-row"><small>المستوى</small><b class="num">${m.lvl.level}</b></div><div class="v08-prog"><i style="width:${m.lvl.goal?Math.min(100,Math.max(0,m.lvl.remain/m.lvl.goal*100)):100}%"></i></div><small>${num(m.xp)} XP مكتسبة من أنشطتك المسجلة</small><div class="v08-row"><small>📚 دراسة</small><b>${num(m.study)} دقيقة</b></div><div class="v08-row"><small>🔥 سعرات</small><b>${num(m.calories)} / ${num(m.calorieGoal)}</b></div><div class="v08-row"><small>💧 ماء</small><b>${num(m.water)} مل</b></div><div class="v08-row"><small>⚖️ آخر وزن</small><b>${m.weight===null?'لم يسجل':num(m.weight,1)+' كجم'}</b></div></div>
<div class="v08-sidecard"><h3>⚡ تسجيل سريع</h3><div class="v08-actions">${[['fullFood','🍽️ وجبة'],['evoGym','💪 تمرين'],['evoWeight','⚖️ وزن'],['study','📚 مذاكرة'],['fullSleep','🌙 نوم'],['expense','💰 مصروف'],['calendar','📅 موعد'],['fullBooks','📖 قراءة']].map(([id,title])=>`<button data-v08-act="${id}">${title}</button>`).join('')}</div></div>
<div class="v08-sidecard"><h3>🕔 توقيت سلطنة عُمان</h3><div style="font-size:22px;color:#ffdaae;font-weight:800" id="v08-clock">${clock()}</div><small>المشاهد افتراضية، والوقت مأخوذ من ساعة الجهاز.</small></div>`;}
function nav(){return `<div class="v08-logo"><strong>♛ GLOW UP RPG</strong><small>V0.08 · REAL LIFE / الحياة الواقعية</small></div>
${[['scene','🖼️ المشهد التفاعلي'],['catalog','🗺️ جميع المواقع'],['phone','📱 الهاتف الافتراضي'],['progress','📊 لوحة التقدم'],['university','🎓 الجامعة'],['vehicle','🚗 السيارة'],['tasks','🎯 المهمات'],['designs','🎨 تصاميم الواجهات']].map(([id,title])=>`<button class="v08-tab ${tab===id?'active':''}" data-v08-tab="${id}">${title}</button>`).join('')}
<hr class="v08-rule"><div class="v08-menu-title" style="padding:4px 12px;color:#b5a68f;font-size:12px">المناطق</div>
${groups.map(([id,label])=>`<button class="v08-navitem ${tab==='catalog'&&catalogGroup===id?'active':''}" data-v08-group="${id}">${label}<em>${scenes.filter(s=>s.group===id).length}</em></button>`).join('')}
<hr class="v08-rule"><button class="v08-tab" data-v08-act="windowsCenter">🛠️ مركز التحكم والتحديثات</button><button class="v08-tab" data-v08-close="1">✕ الرجوع للعبة الأساسية</button>`;}
function hotspots(s){return s.hot.map(h=>`<button class="v08-pin" style="left:${h.x}%;top:${h.y}%" data-v08-${h.kind==='scene'?'go':h.kind==='action'?'act':'tab'}="${h.id}" title="${safe(h.title)}" aria-label="${safe(h.title)}"><i></i>${safe(h.title)}</button>`).join('');}
function sceneView(){const s=mapId.get(active)||scenes[0];const siblings=scenes.filter(x=>x.group===s.group);const favorite=data().favs.includes(s.id);
 const hour=omanHour();return `<div class="v08-scene"><img class="v08-photo ${hour>=19||hour<6?'night':hour<10?'morning':''}" src="${path(s.img)}" alt="${safe(s.title)}" fetchpriority="high"><div class="v08-gradient"></div><div class="v08-scene-tag"><b>${safe(s.title)}</b><small>انقر على العلامات المضيئة للتفاعل</small></div>${hotspots(s)}
 <div class="v08-bottom"><div><button data-v08-fav="${s.id}">${favorite?'★ في المفضلة':'☆ أضف للمفضلة'}</button> <button data-v08-tab="notes">📝 ملاحظات المكان</button></div><span>⏱️ لا تُمنح نقاط خبرة بمجرد دخول مشهد افتراضي.</span><button data-v08-tab="catalog">🗺️ الأماكن</button></div></div>
 <div class="v08-footnav">${siblings.map(x=>`<button class="${x.id===s.id?'active':''}" data-v08-go="${x.id}">${safe(x.title)}</button>`).join('')}</div>`;}
function catalogView(){let arr=scenes.filter(s=>(catalogGroup==='all'||s.group===catalogGroup)&&(!search||s.title.includes(search)||s.id.includes(search.toLowerCase())));
 return `<div class="v08-viewport"><div class="v08-note">🗺️ عالم صوري تفاعلي مستوحى من مواقع في سلطنة عُمان، وليس نظام خرائط GPS. اضغط أي مكان للدخول إلى المشهد والتفاعل مع العناصر.</div><div style="display:flex;gap:7px;flex-wrap:wrap">${[['all','كل المواقع'],...groups].map(([id,t])=>`<button class="v08-btn ${catalogGroup===id?'primary':''}" data-v08-group="${id}">${t}</button>`).join('')}</div>
 <input class="v08-search" id="v08-search" placeholder="🔍 ابحث: الجامعة، المطبخ، المكتبة..." value="${safe(search)}" maxlength="80"><div class="v08-grid" id="v08-cards">${catalogCards(arr)}</div></div>`;}
function catalogCards(arr){return arr.map(x=>`<button class="v08-card" data-v08-go="${x.id}"><img src="${path(x.img)}" alt="" loading="lazy"><span><strong>${safe(x.title)}</strong><small>دخول ←</small></span></button>`).join('')||'<p>لا توجد مشاهد مطابقة.</p>';}
function progressView(){const m=metrics(),s=state(),ex=s.expansion05||{},foods=a(ex.foods),weights=a(ex.weight).filter(x=>Number.isFinite(Number(x.kg))).slice(-16);const nextQuest=a(s.quests).filter(x=>!x.done).slice(0,3);
 const weightLine=weights.length>=2?plotWeight(weights):'<p style="color:#b9c2d3">سجّل قياسين على الأقل لعرض الرسم البياني.</p>';
 return `<div class="v08-viewport"><h2>📊 لوحة التقدم الواقعي</h2><p class="v08-note">هذه القيم مستخرجة من سجلات اللعبة الحقيقية، وليست أرقامًا توضيحية داخل صورة التصميم.</p>
 <div class="v08-metrics">${statCard('⭐ نقاط الخبرة',num(m.xp),'XP')}${statCard('🔥 السعرات اليوم',num(m.calories),'kcal')}${statCard('🥩 البروتين',num(m.protein,1),'g')}${statCard('🍚 الكربوهيدرات',num(m.carbs,1),'g')}${statCard('🥑 الدهون',num(m.fat,1),'g')}${statCard('📚 المذاكرة',num(m.study),'دقيقة')}${statCard('🏋️ سجلات الجولات',num(m.gym))}${statCard('💸 مصروفات اليوم',num(m.expense,3),'ر.ع')}${statCard('🎯 مهام مفتوحة',num(m.quests))}</div>
 <div class="v08-sidecard"><h3>⚖️ الوزن (${m.weight===null?'لم يسجّل':num(m.weight,1)+' كجم'}) · الهدف ${num(m.goalWeight,1)} كجم</h3>${weightLine}<div class="v08-actions"><button data-v08-act="evoWeight">+ أضف قياس الوزن</button><button data-v08-act="evoTargets">تعديل أهداف التغذية</button></div></div>
 <div class="v08-sidecard"><h3>📋 المهام القادمة</h3>${nextQuest.map(x=>`<div class="v08-row"><span>${safe(x.name)}</span><small>مفتوحة</small></div>`).join('')||'<p>لا توجد مهام مفتوحة.</p>'}<button class="v08-btn" data-v08-act="quests">عرض المهام</button></div>
 <div class="v08-sidecard"><h3>📈 تفاصيل أخرى</h3><div class="v08-actions"><button data-v08-act="evoAchievements">🏆 الإنجازات</button><button data-v08-act="world07Week">📅 ملخص الأسبوع</button><button data-v08-act="fullGym">🏋️ التمارين</button><button data-v08-act="fullFood">🥗 التغذية</button></div></div></div>`;}
function plotWeight(weights){const vals=weights.map(x=>Number(x.kg));let lo=Math.min(...vals)-1,hi=Math.max(...vals)+1;const dots=vals.map((v,i)=>[(i*100/(vals.length-1)).toFixed(2),(90-(v-lo)/(hi-lo)*80).toFixed(2)]);const points=dots.map(x=>x.join(',')).join(' ');
 return `<svg viewBox="0 0 100 100" preserveAspectRatio="none" role="img" aria-label="تغير قياسات الوزن" style="display:block;width:100%;height:145px;background:#101724;border-radius:8px"><polyline points="${points}" stroke="#f3c689" stroke-width="1.5" fill="none" vector-effect="non-scaling-stroke"/>${dots.map(([x,y])=>`<circle cx="${x}" cy="${y}" r="1.2" fill="#8dcaee"/>`).join('')}</svg><div style="display:flex;justify-content:space-between;font-size:12px;color:#adbcd0"><span>${safe(weights[0]?.day||'')}</span><span>${safe(weights.at(-1)?.day||'')}</span></div>`;}
function phoneView(){const m=metrics(),events=a(state().events).filter(x=>x.day>=today()).sort((x,y)=>(x.day+x.time).localeCompare(y.day+y.time)).slice(0,5);
 return `<div class="v08-viewport"><h2>📱 GLOW PHONE</h2><p class="v08-note">هاتف داخل لعبة ويندوز وليس تطبيقًا للآيفون. ينقلك إلى الأنظمة الموجودة ويسحب المهام والمواعيد المسجلة.</p><div class="v08-metrics">${statCard('📆 اليوم',today())}${statCard('🕔 توقيت عُمان',clock())}${statCard('✅ الأنشطة اليوم',num(m.acts))}${statCard('🎯 مهمات مفتوحة',num(m.quests))}</div>
 <div class="v08-grid">${[['fullFood','🍽️ التغذية','home_kitchen'],['evoGym','🏋️ التمرين','gym_machines'],['calendar','📅 التقويم','ui_calendar'],['fullBooks','📖 الكتب','bookstore'],['bankAccounts','💰 المال','ui_desktop'],['fullTV','🎬 الترفيه','home_living'],['fullWork','💼 المشاريع','home_desk'],['evoAchievements','🏆 الإنجازات','ui_achievements']].map(([act,title,img])=>`<button class="v08-card" data-v08-act="${act}"><img src="${path(img)}" alt="" loading="lazy"><span><strong>${title}</strong><small>فتح ↗</small></span></button>`).join('')}</div>
 <h3 style="margin-top:18px">📅 مواعيدي القادمة</h3><div class="v08-list">${events.map(x=>`<div class="v08-line"><strong>${safe(x.name)}</strong><small>${safe(x.day)} · ${safe(x.time)}</small></div>`).join('')||'<div class="v08-note">لم تسجل مواعيد قادمة بعد.</div>'}</div>
 <div style="margin-top:15px;display:flex;gap:8px;flex-wrap:wrap"><button class="v08-btn primary" data-v08-act="calendar">＋ إضافة موعد</button><button class="v08-btn" data-v08-tab="football">⚽ مباريات برشلونة</button></div></div>`;}
function universityView(){const s=state(),a0=a(s.activities).filter(x=>['lecture','study'].includes(x.sessionType)),mins=a0.reduce((v,x)=>v+(Number(x.min)||0),0);
 return `<div class="v08-viewport"><h2>🎓 الحياة الجامعية</h2><div class="v08-note">📍 جامعة السلطان قابوس · كلية الآداب والعلوم الاجتماعية · تخصص التاريخ. هذه بيانات تعريفية وليست مزامنة تلقائية مع نظام الجامعة.</div><div class="v08-metrics">${statCard('📚 جلسات دراسة ومحاضرات',num(a0.length))}${statCard('⏱️ دقائق مسجلة',num(mins))}${statCard('🎓 جلسات هذا اليوم',num(a0.filter(x=>x.day===today()).length))}</div>
 <div class="v08-grid">${[['squ_arts','كلية الآداب'],['squ_lecture','قاعة المحاضرات'],['squ_library','مكتبة الجامعة'],['squ_study','طاولة الدراسة']].map(([id,title])=>`<button class="v08-card" data-v08-go="${id}"><img src="${path(id)}" loading="lazy" alt=""><span><b>${title}</b><small>دخول</small></span></button>`).join('')}</div>
 <div class="v08-footnav" style="margin-top:15px"><button data-v08-act="study">⏱️ جلسة مذاكرة</button><button data-v08-act="lecture">📚 حضور محاضرة</button><button data-v08-act="calendar">📅 جدول المواعيد</button><button data-v08-act="fullBooks">📖 الكتب</button></div></div>`;}
function vehicleView(){const x=a((state().expansion05||{}).car),trips=a((state().expansion05||{}).trips);
 return `<div class="v08-viewport"><h2>🚗 Honda Accord Sport 2.0T — 2021</h2><p class="v08-note">السيارة السوداء جزء من عالمك المرئي. سجل الوقود والصيانة يدويًا؛ لا تتصل اللعبة بحساسات السيارة.</p><img class="v08-showcase" src="${path('car_exterior')}" alt="سيارة هوندا أكورد سوداء"><div class="v08-metrics" style="margin-top:14px">${statCard('🧾 سجلات السيارة',num(x.length))}${statCard('🗺️ الرحلات المسجلة',num(trips.length))}</div>
 <div class="v08-footnav"><button data-v08-go="car_cockpit">🚘 المقصورة</button><button data-v08-go="car_fuel">⛽ محطة الوقود</button><button data-v08-go="car_wash">🧽 المغسلة</button><button data-v08-act="expense">💸 مصروفات السيارة</button><button data-v08-act="fullTravel">🗺️ سجل رحلة</button></div>
 <h3 style="margin-top:20px">🔧 سجل صيانة ووقود مستقل</h3><form id="v08-carform" class="form"><label>العملية<select name="type" required><option>وقود</option><option>صيانة</option><option>غسيل</option><option>فحص</option><option>أخرى</option></select></label><label>الوصف<input name="name" maxlength="100" placeholder="مثال: تغيير زيت المحرك" required></label><div class="cols"><label>التكلفة (ر.ع)<input name="cost" type="number" min="0" max="100000" step="0.001" required></label><label>العداد (كم) اختياري<input name="km" type="number" min="0" max="2000000"></label></div><button class="v08-btn primary">＋ حفظ السجل</button></form>
 <p class="v08-note" style="margin-top:10px">ملاحظة: هذا سجل مرجعي ولا يخصم المبلغ من رصيد البنك تلقائيًا، حتى لا يتكرر الخصم. استخدم زر مصروفات السيارة لتسجيله ماليًا.</p>
 <div class="v08-list">${x.slice(-8).reverse().map(e=>`<div class="v08-line"><span><strong>${safe(e.type||'خدمة')} — ${safe(e.name||'')}</strong><small>${safe(e.day||'')} · ${num(e.km)} كم</small></span><b>${num(e.cost,3)} ر.ع</b></div>`).join('')||'<div>لا توجد سجلات بعد.</div>'}</div></div>`;}
function tasksView(){const s=state(),pending=a(s.quests).filter(x=>!x.done),complete=a(s.quests).filter(x=>x.done);
 return `<div class="v08-viewport"><h2>🎯 المهمات الحقيقية</h2><div class="v08-metrics">${statCard('مهام مفتوحة',num(pending.length))}${statCard('مهام مكتملة',num(complete.length))}${statCard('XP الكلي',num(s.xp))}</div><div class="v08-footnav"><button data-v08-act="quests">📋 إدارة المهام</button><button data-v08-act="newQuest">＋ مهمة جديدة</button><button data-v08-act="evoAchievements">🏆 الإنجازات</button></div>
 <div class="v08-list">${pending.map(x=>`<div class="v08-line"><strong>${safe(x.name)}</strong><small>مفتوحة</small></div>`).join('')||'<div class="v08-note">لا توجد مهام مفتوحة.</div>'}</div></div>`;}
function notesView(){const o=data();return `<div class="v08-viewport"><h2>📝 دفتر المكان: ${safe(mapId.get(active).title)}</h2><p class="v08-note">تُحفظ هذه الملاحظات ضمن تقدمك في اللعبة وعلى خادم ويندوز المحلي عند اتصال الحفظ.</p><form id="v08-noteform"><textarea name="text" maxlength="1500" placeholder="ما الذي تريد تذكره هنا؟">${safe(o.notes[active]||'')}</textarea><div style="margin-top:12px"><button class="v08-btn primary">💾 حفظ الملاحظة</button><button class="v08-btn" type="button" data-v08-tab="scene">↩ العودة للمشهد</button></div></form></div>`;}
function designsView(){const [id,title]=uiScreens[activeUi];return `<div class="v08-viewport"><h2>🎨 مرجع تصميم الواجهات — ${safe(title)}</h2><div class="v08-note">هذه الصور المولدة مرجع بصري فقط؛ الأزرار والأرقام الظاهرة داخل الصورة غير تفاعلية وقد تكون أمثلة. استخدم القوائم الحقيقية الموجودة في هذا الإصدار.</div>
 <img class="v08-showcase" src="${path(id)}" alt="${safe(title)}"><div class="v08-gallerynav">${uiScreens.map(([key,label],i)=>`<button class="v08-btn ${i===activeUi?'primary':''}" data-v08-ui="${i}">${safe(label)}</button>`).join('')}</div></div>`;}
async function updateFootball(force=false){if(football.loading||(!force&&Date.now()-football.last<300000))return;football.loading=true;football.error=null;if(tab==='football')render();
 try{const res=await fetch('/api/football',{cache:'no-store'});if(!res.ok)throw Error('تعذر الوصول إلى المصدر الرياضي: HTTP '+res.status);const obj=await res.json();football.matches=a(obj.matches).filter(v=>{const d=new Date(v.date);return !isNaN(d)&&d.getTime()>=Date.now()-90*60000}).sort((x,y)=>new Date(x.date)-new Date(y.date));football.error=obj.message&&!football.matches.length?obj.message:null;football.last=Date.now();}
 catch(err){football.error=String(err.message||err);football.last=Date.now();}finally{football.loading=false;if(gameOpen&&tab==='football')render();}}
function footballView(){return `<div class="v08-viewport"><h2>⚽ برشلونة — الفريق الأول للرجال</h2><div class="v08-note">المباريات من خادم اللعبة المتصل بمصدر ESPN، ومواعيد العرض بتوقيت مسقط. إذا لم تتوفر مباريات مستقبلية يعرض النظام السبب بدل إضافة مواعيد وهمية.</div>
 <button class="v08-btn primary" data-v08-refresh-football="1">🔄 تحديث المباريات</button><div class="v08-list">${football.loading?'<div class="v08-note">جارٍ التحديث...</div>':football.error?`<div class="v08-note">⚠️ ${safe(football.error)}</div>`:football.matches.length?football.matches.slice(0,20).map(x=>`<div class="v08-line"><span><strong>${safe(x.home)} × ${safe(x.away)}</strong><small>${safe(x.status||'مجدولة')} · ${safe(x.type||'مباراة')}</small></span><b>${new Date(x.date).toLocaleString('ar-OM',{timeZone:'Asia/Muscat',dateStyle:'medium',timeStyle:'short'})}</b></div>`).join(''):'<div class="v08-note">لا توجد مباريات مستقبلية في البيانات المتاحة من المصدر الآن.</div>'}</div></div>`;}
function body(){switch(tab){case 'scene':return sceneView();case 'catalog':return catalogView();case 'progress':return progressView();case 'phone':return phoneView();case 'university':return universityView();case 'vehicle':return vehicleView();case 'tasks':return tasksView();case 'notes':return notesView();case 'designs':return designsView();case 'football':return footballView();default:return sceneView();}}
function render(){if(!gameOpen)return;const e=q('#v08-shell'),s=mapId.get(active)||scenes[0];e.innerHTML=`<div class="v08-layout"><aside class="v08-nav">${nav()}</aside><main class="v08-center"><header class="v08-top"><div><h2>🌆 REAL LIFE — ${tab==='scene'?safe(s.title):'عالم الحياة'}</h2><small>${today()} · تطوير حياتك الواقعية من عالم تفاعلي</small></div><div class="v08-tool"><button class="v08-btn" data-v08-tab="phone">📱 الهاتف</button><button class="v08-btn" data-v08-tab="catalog">🗺️ المواقع</button><button class="v08-btn danger" data-v08-close="1">✕</button></div></header>${body()}</main><aside class="v08-stats">${mainSide()}</aside></div>`;
 if(tab==='catalog'&&search){const input=q('#v08-search',e);if(input){input.focus();input.setSelectionRange(search.length,search.length);}}}
function ensureMount(){if(q('#v08-shell'))return;const overlay=document.createElement('div');overlay.id='v08-shell';overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');overlay.setAttribute('tabindex','-1');overlay.setAttribute('aria-label','GLOW UP RPG — العالم التفاعلي');document.body.appendChild(overlay);
 const attach=q('#w07-ribbon')||q('#evo-mount')||q('.stats-strip');if(attach&&!q('#v08-entry')){
  const entry=document.createElement('section');entry.id='v08-entry';entry.innerHTML=`<div class="v08-cover"></div><div class="v08-entry-body"><small>GLOW UP RPG · 0.08 REAL LIFE</small><h2>🌍 ادخل عالمك الواقعي الجديد</h2><p>44 صورة مدمجة، 36 موقعًا تفاعليًا، مهام حقيقية، غذاء، جامعة، جيم، سيارة، وهاتف افتراضي متصل بتقدمك.</p><div class="v08-entry-row"><button type="button" data-v08-open="1">🎮 دخول العالم التفاعلي ←</button><small>التنقل داخل المشاهد لا يُحتسب كنشاط حقيقي.</small></div></div>`;
  attach.insertAdjacentElement('afterend',entry);
 }
 const loc=q('#locations');if(loc&&!loc.querySelector('[data-action="world08"]'))loc.insertAdjacentHTML('afterbegin','<button class="locbtn" data-action="world08">🌆 عالم V0.08</button>');}
// Prevent underlying game click handlers from handling internal world interactions.
document.addEventListener('click',e=>{const btn=e.target.closest('[data-v08-open],[data-v08-close],[data-v08-go],[data-v08-tab],[data-v08-group],[data-v08-fav],[data-v08-act],[data-v08-ui],[data-v08-refresh-football]');if(!btn)return;e.preventDefault();e.stopImmediatePropagation();
 if(btn.hasAttribute('data-v08-open')){openWorld();return;}
 if(btn.hasAttribute('data-v08-close')){closeWorld();return;}
 if(btn.dataset.v08Go){sceneGo(btn.dataset.v08Go);return;}
 if(btn.dataset.v08Tab){displayTab(btn.dataset.v08Tab);if(tab==='football')updateFootball();return;}
 if(btn.dataset.v08Group){catalogGroup=btn.dataset.v08Group;tab='catalog';search='';render();return;}
 if(btn.dataset.v08Fav){toggleFav(btn.dataset.v08Fav);return;}
 if(btn.dataset.v08Act){launch(btn.dataset.v08Act);return;}
 if(btn.dataset.v08Ui!==undefined){activeUi=Number(btn.dataset.v08Ui)||0;render();return;}
 if(btn.hasAttribute('data-v08-refresh-football')){updateFootball(true);return;}
},true);
document.addEventListener('input',e=>{if(e.target.id==='v08-search'){search=String(e.target.value||'').slice(0,80);const box=q('#v08-cards');if(box)box.innerHTML=catalogCards(scenes.filter(x=>(catalogGroup==='all'||x.group===catalogGroup)&&(!search||x.title.includes(search)||x.id.includes(search.toLowerCase()))));}});
document.addEventListener('submit',e=>{const f=e.target;if(!['v08-noteform','v08-carform'].includes(f.id))return;e.preventDefault();e.stopImmediatePropagation();if(f.id==='v08-noteform'){data().notes[active]=String(new FormData(f).get('text')||'').trim().slice(0,1500);g.save();g.toast('✓ حُفظت ملاحظة المكان');return;}
 const v=Object.fromEntries(new FormData(f)),cost=Number(v.cost),km=v.km===''?null:Number(v.km);
 if(!String(v.name||'').trim()||!Number.isFinite(cost)||cost<0||cost>100000||(km!==null&&(!Number.isFinite(km)||km<0||km>2000000)))return g.toast('تحقق من حقول السيارة');
 const s=state();s.expansion05??={};s.expansion05.car=a(s.expansion05.car);s.expansion05.car.push({id:crypto.randomUUID?.()||String(Date.now()),day:today(),type:String(v.type).slice(0,30),name:String(v.name).trim().slice(0,100),cost,km});g.save();render();g.toast('✓ حُفظ سجل السيارة');
},true);
document.addEventListener('keydown',e=>{if(!gameOpen)return;if(e.key==='Escape'&&!q('#modal')?.open){e.preventDefault();closeWorld();return;}if(e.key.toLowerCase()==='g'&&!e.ctrlKey&&!e.altKey&&!e.metaKey&&!e.target.closest('input,textarea,select')){e.preventDefault();displayTab('catalog');}},true);
window.glowExtraActions??={};window.glowExtraActions.world08=openWorld;
ensureMount();window.addEventListener('glow:changed',()=>{if(gameOpen&&['progress','tasks','phone','university','vehicle'].includes(tab)){clearTimeout(render._timer);render._timer=setTimeout(render,120);}});
setInterval(()=>{if(!gameOpen)return;const el=q('#v08-clock');if(el)el.textContent=clock();const photo=q('#v08-shell .v08-photo');if(photo){const hour=omanHour();photo.classList.toggle('night',hour>=19||hour<6);photo.classList.toggle('morning',hour>=6&&hour<10);}},30000);
})();

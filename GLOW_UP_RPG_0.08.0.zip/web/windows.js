(()=>{'use strict';
const g=window.glowBridge;
const esc=g.ESC;
const api=async (p,method='GET',body)=>{const r=await fetch('/api/'+p,{method,headers:{'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{})});const j=await r.json();if(!r.ok)throw Error(j.error||`HTTP ${r.status}`);return j};
let info=null,update=null;
function fileInput(){let v=document.getElementById('win-import');return v;}
async function panel(message=''){
  try{info=await api('system/info')}catch(err){return g.toast('تعذر فتح مركز التحكم: '+err.message)}
  let backups=[];try{backups=(await api('backup/list')).items||[]}catch{}
  const status=message?`<div class="notice" style="border-color:#8bd4b5">${esc(message)}</div>`:'';
  const active=update?.update_available;
  g.open('🛠️ مركز التحكم — GLOW UP Windows Edition',`
    <div class="capsule" style="margin-bottom:12px"><h3>🎮 GLOW UP RPG <small class="num">V${esc(info.version)}</small></h3><div class="muted">نسخة ويندوز فقط · يعمل محليًا · لا يحتاج Python</div><div class="muted">💾 مكان الحفظ: <code dir="ltr">${esc(info.data_dir)}</code></div></div>
    ${status}
    <h3>🔄 التحديثات</h3>
    <div class="notice">يظهر إشعار عند نشر تحديث جديد في المصدر الذي تحدده. لن يتم تثبيت أي تحديث دون موافقتك، ويحفظ البرنامج نسخة احتياطية قبل تثبيته.</div>
    <form id="win-feed" class="form"><label>رابط ملف التحديثات الآمن (HTTPS)<input name="feed" type="url" placeholder="https://example.com/glow-up/manifest.json" value="${esc(info.update_url||'')}" style="width:100%;direction:ltr" /></label><div class="wrap"><button class="button primary">💾 حفظ مصدر التحديثات</button><button type="button" class="button" data-win-action="check">🔎 البحث عن تحديث</button>${active?'<button type="button" class="button primary" data-win-action="install">⬇️ تثبيت التحديث</button>':''}</div></form>
    <div id="win-update-status" class="muted" style="margin-top:10px">${update?.update_available?`يتوفر إصدار ${esc(update.latest)}: ${esc(update.notes||'تحسينات وإصلاحات')}`:(update?.error?esc(update.error):'لم يتم فحص التحديثات بعد')}</div>
    <h3>🛡️ النسخ الاحتياطية</h3>
    <div class="wrap"><button class="button primary" data-win-action="backup">＋ إنشاء نسخة احتياطية الآن</button><button class="button" data-win-action="refresh">↻ تحديث القائمة</button></div>
    <div class="scrollarea" style="max-height:250px;margin-top:12px">${backups.length?backups.slice(0,20).map(x=>`<div class="row"><div><b>${esc(x.name)}</b><div class="muted">${esc(new Date(x.date).toLocaleString('ar-OM',{timeZone:'Asia/Muscat'}))} · ${(x.bytes/1024).toFixed(1)} KB</div></div><div class="wrap"><button class="button" data-win-action="download" data-backup="${esc(x.name)}">⬇️ تنزيل</button><button class="button red" data-win-action="restore" data-backup="${esc(x.name)}">↩️ استعادة</button></div></div>`).join(''):'<div class="empty">لا توجد نسخ احتياطية بعد. أنشئ أول نسخة الآن.</div>'}</div>
    <h3>📁 نقل تقدم من نسخة قديمة</h3><p class="muted">اختر ملف <code>state.json</code> من مجلد <code>private_data</code> القديم، أو ملف JSON الذي صدّرته اللعبة سابقًا. لن نستبدل بياناتك قبل أخذ نسخة احتياطية.</p>
    <input type="file" id="win-import" accept="application/json,.json" style="width:100%;margin-bottom:8px" /><div class="wrap"><button class="button" data-win-action="import">📥 استيراد بيانات قديمة</button></div>
    <h3>⚙️ النظام</h3><div class="wrap"><button class="button" data-win-action="save">💾 حفظ التقدم الآن</button><button class="button red" data-win-action="exit">⏻ إغلاق الخادم</button></div>
    <p class="muted">تُحفظ بيانات اللعبة على هذا الكمبيوتر فقط. معلومات المباريات والطقس والصلاة تتطلب اتصالًا بالإنترنت. مصدر التحديثات يُضبط من الأعلى؛ ولا تظهر تحديثات ما لم تُنشر حزمة فعلية وبصمتها الصحيحة.</p>
  `);
}
async function persist(){let current=await api('state');let res=await api('state','POST',{revision:current.revision,state:g.get()});return res}
async function handle(action,el){
 try{
  if(action==='center'||action==='refresh')return panel();
  if(action==='check'){update=await api('update/check');return panel(update.update_available?`🎉 يتوفر إصدار ${update.latest}`:(update.error?`⚠️ ${update.error === 'invalid update manifest'?'ملف التحديثات غير مكتمل: تأكد من version وurl وsha256 الصحيح.':update.error}`:'✅ أنت تستخدم أحدث إصدار منشور'))}
  if(action==='install'){
   if(!update?.update_available)return g.toast('لا يوجد تحديث جديد');
   if(!confirm('سيُنزّل التحديث بعد التحقق من سلامته، وستُنشأ نسخة احتياطية ويعاد تشغيل اللعبة. هل توافق؟'))return;
   await persist();await panel('⏳ يجري تنزيل وتثبيت التحديث. قد يستغرق بعض الوقت، لا تغلق نافذة اللعبة.');
   await api('update/install','POST',{});g.toast('جاري تثبيت التحديث ثم إعادة فتح اللعبة…');return;
  }
  if(action==='backup'){await persist();let r=await api('backup/create','POST',{});return panel('✅ حُفظت نسخة احتياطية: '+r.name)}
  if(action==='download'){let name=el.dataset.backup;if(!name)return;location.href='/api/backup/download?name='+encodeURIComponent(name);return}
  if(action==='restore'){let name=el.dataset.backup;if(!name)return;if(!confirm('تحذير: ستستبدل هذه النسخة تقدمك الحالي. سيُحفظ التقدم الحالي احتياطيًا قبل الاستعادة. متابعة؟'))return;let r=await api('backup/restore','POST',{name});g.set(r.state.state);localStorage.removeItem('glow_v004_pending');g.toast('تمت الاستعادة. سيُعاد تحميل اللعبة.');setTimeout(()=>location.reload(),850);return}
  if(action==='save'){await persist();g.toast('✅ تم حفظ تقدمك على القرص');return}
  if(action==='exit'){if(!confirm('إغلاق خادم اللعبة الآن؟'))return;await api('system/exit','POST',{});g.toast('تم إيقاف اللعبة، يمكنك إغلاق النافذة');setTimeout(()=>window.close(),300);return}
  if(action==='import'){
   const input=fileInput();const file=input?.files?.[0];if(!file)return g.toast('اختر ملف JSON أولًا');
   if(file.size>3_000_000)throw Error('حجم الملف أكبر من المسموح');
   const data=JSON.parse(await file.text());const imported=data?.state?.activities&&data?.state?.accounts?data.state:data;
   if(!Array.isArray(imported?.activities)||!Array.isArray(imported?.accounts))throw Error('الملف لا يحتوي على بيانات لعبة صالحة');
   if(!confirm('سنحفظ تقدمك الحالي احتياطيًا ثم نستورد بيانات الملف. هل تريد المتابعة؟'))return;
   await persist();await api('backup/create','POST',{});
   g.set(imported);await persist();localStorage.removeItem('glow_v004_pending');g.toast('✅ تم استيراد بياناتك القديمة');setTimeout(()=>location.reload(),850);return;
  }
 }catch(e){g.toast('⚠️ '+(e.message||'تعذر إكمال العملية'));if(action==='install')await panel('فشل التحديث: '+e.message)}
}
// Distinct attribute avoids breaking original RPG action handlers.
document.addEventListener('click',e=>{const b=e.target.closest?.('[data-win-action]');if(!b)return;e.preventDefault();handle(b.dataset.winAction,b)});
document.addEventListener('submit',async e=>{if(e.target.id!=='win-feed')return;e.preventDefault();try{const v=new FormData(e.target).get('feed').trim();await api('settings','POST',{manifest_url:v});update=null;await panel('✅ تم حفظ إعدادات التحديثات')}catch(err){g.toast('تعذر حفظ الإعدادات: '+err.message)}});
// Keep the full desktop game; the iPhone companion is not loaded or used.
let btn=document.createElement('button');btn.className='button';btn.textContent='🛠️ مركز التحكم · Windows';btn.dataset.winAction='center';btn.style.cssText='position:fixed;bottom:14px;left:14px;z-index:99;box-shadow:0 8px 28px #000a;border-color:#d4ad80;';document.body.appendChild(btn);
// Check once per app launch without blocking game startup. Never auto-install.
setTimeout(async()=>{try{let i=await api('system/info');if(!i.update_url)return;update=await api('update/check');if(update.update_available)g.toast('🔔 يتوفر تحديث GLOW UP '+update.latest+' — افتح مركز التحكم')}catch{}},6000);
})();

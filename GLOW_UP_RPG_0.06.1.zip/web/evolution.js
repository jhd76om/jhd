(()=>{'use strict';
const g=window.glowBridge;
if(!g){console.error('GLOW EVOLUTION needs glowBridge');return}
const TODAY=()=>g.today(),S=()=>g.get(),safe=x=>g.ESC(String(x??''));
const number=(x,p=0)=>Number(x||0).toLocaleString('en-US',{minimumFractionDigits:p,maximumFractionDigits:p});
const valid=(v,a=0,b=100000)=>Number.isFinite(Number(v))&&Number(v)>=a&&Number(v)<=b;
const iso=x=>typeof x==='string'?x.slice(0,10):'';
const fmt=(x)=>x?String(x).replace('T',' · '):'—';
const ms=(day)=>Date.parse(day+'T00:00:00Z');
const subDay=(d,k)=>new Date(ms(d)-k*86400000).toISOString().slice(0,10);
const targets={kcal:2500,protein:90,carbs:325,fat:85,weight:55};
function evo(s=S()){
 if(!s.evolution061||typeof s.evolution061!=='object')s.evolution061={targets:{...targets},achievements:[],dismissedTips:[]};
 if(!s.evolution061.targets||typeof s.evolution061.targets!=='object')s.evolution061.targets={...targets};
 for(let k in targets)if(!valid(s.evolution061.targets[k],k==='weight'?20:0,k==='weight'?300:10000))s.evolution061.targets[k]=targets[k];
 if(!Array.isArray(s.evolution061.achievements))s.evolution061.achievements=[];
 return s.evolution061;
}
const expansion=s=>s.expansion05&&typeof s.expansion05==='object'?s.expansion05:{};
const life=s=>s.life05&&typeof s.life05==='object'?s.life05:{};
const arr=v=>Array.isArray(v)?v:[];
function foodToday(s,day=TODAY()){
 const foods=arr(expansion(s).foods).filter(x=>x.day===day);
 let sum={kcal:0,protein:0,carbs:0,fat:0};
 for(const f of foods)for(const k in sum)sum[k]+=valid(f[k],0,100000)?Number(f[k]):0;
 return {...sum,count:foods.length};
}
function latestWeight(s){const a=arr(expansion(s).weight).filter(x=>valid(x.kg,20,400)).slice().sort((a,b)=>(String(a.day||'')+String(a.id||'')).localeCompare(String(b.day||'')+String(b.id||'')));return {first:a[0],last:a.at(-1),count:a.length};}
function sleepToday(s,d=TODAY()){
 const classic=arr(s.sleepEntries).filter(x=>x.day===d&&valid(x.hours,0.25,24)).map(x=>({hours:Number(x.hours),start:x.start||'',source:'journal'}));
 const exp=arr(expansion(s).sleeps).filter(x=>x.day===d&&valid(x.hours,0.25,24)).map(x=>({hours:Number(x.hours),start:x.start||'',source:'tracker'}));
 return [...classic,...exp].at(-1)||null;
}
function studies(s,d=TODAY()){
 const a=arr(s.activities).filter(x=>x.day===d&&['study','lecture'].includes(x.sessionType));
 return a.reduce((n,x)=>n+Math.max(0,Number(x.min||0)),0);
}
function training(s,d=TODAY()){
 return {sessions:arr(s.activities).filter(x=>x.day===d&&x.sessionType==='gymSession').length,
 sets:arr(expansion(s).gymSets).filter(x=>x.day===d).reduce((n,x)=>n+Math.max(0,Number(x.sets)||0),0)};
}
function dailyExpense(s,d=TODAY()){
 const bank=arr(s.transactions).filter(x=>iso(x.date)===d&&x.type==='expense').reduce((n,x)=>n+Math.max(0,Number(x.amount)||0),0);
 const other=arr(life(s).expenses).filter(x=>x.day===d).reduce((n,x)=>n+Math.max(0,Number(x.amount)||0),0);
 return {bank,other};
}
const ALIST=[
 {id:'first',ico:'🌱',name:'البداية القوية',description:'سجل أول نشاط حقيقي في رحلتك',xp:20,coins:8,skill:'DIS',criterion:s=>arr(s.activities).some(a=>a.type!=='achievement')||arr(s.meals).length>0||arr(expansion(s).foods).length>0||arr(expansion(s).gymSets).length>0},
 {id:'streak7',ico:'🔥',name:'سبعة أيام من الاستمرارية',description:'سجل نشاطًا في 7 أيام متتالية',xp:70,coins:25,skill:'DIS',criterion:s=>streak(s)>=7},
 {id:'study600',ico:'🎓',name:'طالب مجتهد',description:'أكمل 10 ساعات دراسة أو محاضرات مسجلة',xp:55,coins:20,skill:'INT',criterion:s=>arr(s.activities).filter(x=>['study','lecture'].includes(x.sessionType)).reduce((v,x)=>v+(Number(x.min)||0),0)>=600},
 {id:'workout5',ico:'🏋️',name:'انطلاقة رياضية',description:'سجل تمارين في 5 أيام مختلفة',xp:45,coins:16,skill:'STR',criterion:s=>new Set([...arr(s.activities).filter(x=>x.sessionType==='gymSession').map(x=>x.day),...arr(expansion(s).gymSets).map(x=>x.day)].filter(Boolean)).size>=5},
 {id:'finance7',ico:'💳',name:'الإدارة المالية',description:'سجل مصروفات خلال 7 أيام مختلفة',xp:40,coins:15,skill:'FIN',criterion:s=>new Set([...arr(s.transactions).filter(x=>x.type==='expense').map(x=>iso(x.date)),...arr(life(s).expenses).map(x=>x.day)].filter(Boolean)).size>=7}
];
function recordedDays(s){return new Set([
 ...arr(s.activities).filter(x=>x.type!=='achievement').map(x=>x.day),
 ...arr(s.meals).map(x=>x.day),...arr(s.waterEntries).map(x=>x.day),
 ...arr(s.sleepEntries).map(x=>x.day),...arr(expansion(s).foods).map(x=>x.day),
 ...arr(expansion(s).gymSets).map(x=>x.day),...arr(expansion(s).weight).map(x=>x.day),
 ...arr(s.transactions).filter(x=>x.type==='expense'||x.type==='income').map(x=>iso(x.date))
 ].filter(d=>/^\d{4}-\d\d-\d\d$/.test(d)))}
function streak(s){const set=recordedDays(s);let d=TODAY();if(!set.has(d))d=subDay(d,1);let n=0;while(set.has(d)&&n<10000){n++;d=subDay(d,1)}return n;}
let busy=false;
function checkAchievements(){
 if(busy)return;busy=true;
 try{
  const s=S(),meta=evo(s),past=new Set(meta.achievements.map(a=>a.id));let newly=[];
  for(const a of ALIST){if(!past.has(a.id)&&a.criterion(s)){const row={id:a.id,day:TODAY(),at:new Date().toISOString(),xp:a.xp};meta.achievements.push(row);past.add(a.id);s.xp=Math.max(0,Number(s.xp)||0)+a.xp;s.coins=Math.max(0,Number(s.coins)||0)+a.coins;s.skillXP??={};s.skillXP[a.skill]=(Number(s.skillXP[a.skill])||0)+a.xp;s.logs??=[];s.logs.unshift({kind:'achievement',name:a.ico+' '+a.name,xp:a.xp,coins:a.coins,skill:a.skill,note:'إنجاز دائم • V0.06.1',date:TODAY()+' 12:00:00',achievementId:a.id});newly.push(a.name)} }
  if(newly.length){g.save();g.render();g.toast('🏆 إنجاز جديد: '+newly.join('، '))}
 }catch(e){console.warn('achievement check:',e)}finally{busy=false}
}
function meter(value,target){return `<div class="evo-fill"><i style="width:${Math.max(0,Math.min(100,Number(value||0)/Math.max(1,Number(target||1))*100))}%"></i></div>`}
function card(icon,label,value,unit,sub,fill,goal){return `<div class="evo-card"><small>${icon} ${label}</small><div><b class="evo-value">${value}</b> <small style="display:inline">${unit}</small></div><div class="evo-meta">${sub}</div>${goal?meter(fill,goal):''}</div>`}
function nextEvents(s){const d=TODAY();let all=[];try{all=typeof window.glowUpcomingEvents==='function'?window.glowUpcomingEvents():[]}catch{}if(!all.length)all=arr(s.events).map(x=>({title:x.name,date:x.day+'T'+(x.time||'12:00'),type:'شخصي'}));return all.filter(x=>typeof x.date==='string'&&x.date.slice(0,10)>=d).sort((a,b)=>a.date.localeCompare(b.date)).slice(0,3).map(x=>({name:x.title||x.name,day:x.date.slice(0,10),time:x.date.slice(11,16),type:x.type||'حدث'}))}
function render(){
 const host=document.querySelector('#evo-mount');if(!host)return;
 const s=S(),meta=evo(s),d=TODAY(),food=foodToday(s,d),weight=latestWeight(s),sleep=sleepToday(s,d),gy=training(s,d),study=studies(s,d),expense=dailyExpense(s,d),events=nextEvents(s);
 const level=(x=>{let level=1,remain=Math.max(0,x);while(level<100){let req=100+25*(level-1)+5*(level-1)**2;if(remain<req)return {level,remain,req};remain-=req;level++}return {level,remain,req:1}})(Number(s.xp)||0);
 const cnt=meta.achievements.length;
 host.innerHTML=`<section class="evo" aria-label="لوحة تقدم اليوم"><div class="evo-top"><div><h2>✨ لوحة التطور اليومي <small class="evo-tag">NEW</small></h2><p>إحصائيات من سجلاتك الفعلية · توقيت سلطنة عُمان · ${safe(d)}</p></div><span class="evo-pill">THE FIRST EVOLUTION · V0.06.1</span></div><div class="evo-body">
 <div class="evo-grid">
 ${card('🔥','السعرات',number(food.kcal),'kcal',`الهدف الشخصي: ${number(meta.targets.kcal)} · ${food.count} إدخال`,food.kcal,meta.targets.kcal)}
 ${card('⚖️','الوزن',weight.last?number(weight.last.kg,1):'—','kg',weight.first&&weight.last?`التغير: ${(weight.last.kg-weight.first.kg)>=0?'+':''}${number(weight.last.kg-weight.first.kg,1)} كجم · الهدف ${number(meta.targets.weight,1)}`:'لم تسجّل وزنك بعد',weight.last?.kg||0,meta.targets.weight)}
 ${card('😴','النوم',sleep?number(sleep.hours,1):'—','h',sleep?'آخر جلسة مسجلة اليوم':'لا توجد جلسة لليوم',sleep?.hours||0,8)}
 ${card('📚','المذاكرة',number(study),'دقيقة',`${number(study/60,1)} ساعة مسجلة`,study,120)}
 ${card('🏋️','النادي',number(gy.sessions),'جلسة',`${number(gy.sets)} جولة مقاومة مسجلة`,gy.sessions,1)}
 ${card('💧','الماء',number(arr(s.waterEntries).filter(x=>x.day===d).reduce((n,x)=>n+(Number(x.ml)||0),0)),'ml',`هدفك: ${number(s.hydrationGoal||2000)} ml`,arr(s.waterEntries).filter(x=>x.day===d).reduce((n,x)=>n+(Number(x.ml)||0),0),s.hydrationGoal||2000)}
 ${card('🏆','الإنجازات',number(cnt),'/ '+ALIST.length,`سلسلة الاستمرارية: ${streak(s)} يوم`,cnt,ALIST.length)}
 ${card('💰','المصروفات',number(expense.bank,3),'OMR',expense.other?`+ ${number(expense.other,3)} ر.ع في السجل المنفصل`:'من حسابات البنك داخل اللعبة',0,0)}
 </div>
 <div class="evo-wide">
 <div class="evo-slab"><h3>🥗 المغذيات الكبرى</h3><div class="evo-macros">${[['protein','🥩 بروتين'],['carbs','🍚 كارب'],['fat','🥑 دهون']].map(([k,t])=>`<div class="evo-macro"><small>${t}</small><b>${number(food[k],1)} g</b><small>من ${number(meta.targets[k])} g</small>${meter(food[k],meta.targets[k])}</div>`).join('')}</div><div class="evo-note">تعتمد الأرقام على وجبات سجل السعرات فقط؛ لا نخمن العناصر الغذائية من أسماء الأطباق.</div></div>
 <div class="evo-slab"><h3>📅 القادم في تقويمك</h3>${events.length?events.map(x=>`<div class="evo-minirow"><span>${x.type==='football'?'⚽ ':''}${safe(x.name||'موعد')}</span><b class="num">${safe(x.day)} ${safe(x.time||'')}</b></div>`).join(''):'<div class="evo-empty">لا توجد مواعيد مؤكدة قادمة؛ مباريات برشلونة تظهر هنا عند توفرها من المصدر الرياضي.</div>'}<div class="evo-minirow"><span>⭐ نقاط المستوى ${level.level}</span><b class="num">${number(level.remain)} / ${number(level.req)} XP</b></div>${meter(level.remain,level.req)}</div>
 </div>
 <div class="evo-actions"><button class="button primary" data-evo="food">＋ تسجيل وجبة</button><button class="button" data-evo="weight">⚖️ الوزن</button><button class="button" data-evo="gym">🏋️ التمرين</button><button class="button" data-evo="study">📚 المذاكرة</button><button class="button" data-evo="achievements">🏆 الإنجازات</button><button class="button" data-evo="targets">⚙️ أهدافي</button><button class="button" data-action="calendarPlus">📅 التقويم</button></div>
 </div></section>`;
}
function achievements(){const meta=evo(),s=S();g.open('🏆 WALL OF FAME — جدار الإنجازات',`<div class="notice">المكافآت تُضاف مرة واحدة لكل إنجاز، ولا تُحتسب الأنشطة الوهمية. لا يُلغى الإنجاز بعد تحقيقه.</div><div class="evo-minirow"><b>إجمالي الإنجازات المفتوحة</b><b>${meta.achievements.length} / ${ALIST.length}</b></div>${ALIST.map(a=>{let rec=meta.achievements.find(x=>x.id===a.id);return `<div class="evo-achievement ${rec?'':'locked'}"><div class="evo-medal">${a.ico}</div><div><div class="evo-title">${safe(a.name)} ${rec?'✓':''}</div><small>${safe(a.description)}</small><small>${rec?'فُتح يوم '+safe(rec.day):'لم يتحقق بعد'}</small></div><span class="evo-award">+${a.xp} XP</span></div>`}).join('')}<p class="evo-note">نقاط XP مقياس تحفيزي للعبة وليست مقياسًا لصحتك أو قيمتك الشخصية.</p>`)}
function settingPage(){const t=evo().targets;g.open('🎯 أهداف التقدم — Personal Targets',`<div class="notice">الأهداف قابلة للتعديل وتُستخدم لمؤشرات العرض فقط. لا تُعد توصيات غذائية أو طبية.</div><form class="form" id="evo-targets"><div class="evo-form-row"><label>🔥 السعرات اليومية<input name="kcal" type="number" min="500" max="10000" step="10" value="${t.kcal}" required></label><label>⚖️ الوزن المستهدف (كجم)<input name="weight" type="number" min="20" max="300" step="0.1" value="${t.weight}" required></label><label>🥩 البروتين (جم)<input name="protein" type="number" min="0" max="1000" value="${t.protein}" required></label><label>🍚 الكربوهيدرات (جم)<input name="carbs" type="number" min="0" max="1500" value="${t.carbs}" required></label><label>🥑 الدهون (جم)<input name="fat" type="number" min="0" max="500" value="${t.fat}" required></label></div><button class="button primary">💾 حفظ الأهداف</button></form><p class="evo-note">قيم البداية توضيحية ويمكن تغييرها بما يناسب خطة التغذية المتفق عليها مع المختص.</p>`)}
function weightPage(){const s=S(),w=latestWeight(s);g.open('⚖️ WEIGHT JOURNAL — متابعة الوزن',`<div class="notice">هدفك المسجل ${number(evo(s).targets.weight,1)} كجم · استخدم ميزانًا واحدًا وظروف قياس متشابهة للمقارنة.</div><form class="form" id="evo-weight"><div class="evo-form-row"><label>الوزن (كجم)<input type="number" name="kg" min="20" max="400" step="0.1" placeholder="مثال: 41.0" value="${w.last?.kg||''}" required></label><label>تاريخ القياس<input type="date" name="day" value="${TODAY()}" max="${TODAY()}" required></label></div><button class="button primary">💾 تسجيل الوزن</button></form><h3>القياسات السابقة</h3>${arr(expansion(s).weight).slice().reverse().slice(0,12).map(x=>`<div class="row"><span>${safe(x.day)}</span><b class="num">${number(x.kg,1)} kg</b></div>`).join('')||'<div class="evo-empty">لم تُسجل قياسات بعد.</div>'}`)}
function gymPage(){const s=S(),gy=training(s);g.open('🏋️ WORKOUT JOURNAL — التمرين',`<div class="notice">يمكنك أيضًا تسجيل جلسة كاملة من النادي. هنا تسجل جولات المقاومة والأوزان وتتبعها.</div><form class="form" id="evo-gym"><label>اسم التمرين<input name="exercise" required maxlength="80" placeholder="مثال: ضغط الصدر بالدمبل"></label><div class="evo-form-row"><label>عدد الجولات<input name="sets" type="number" min="1" max="30" required></label><label>التكرارات لكل جولة<input name="reps" type="number" min="1" max="100" required></label><label>الوزن المستخدم بالكيلوجرام<input name="kg" type="number" min="0" max="500" step="0.5" value="0" required></label></div><button class="button primary">＋ تسجيل التمرين</button></form><div class="wrap" style="margin-top:12px"><button class="button" data-action="gymSession">⏱️ تسجيل جلسة نادي كاملة</button><button class="button" data-action="fullGym">📊 برنامجي الرياضي</button></div><h3>آخر السجلات</h3>${arr(expansion(s).gymSets).slice().reverse().slice(0,9).map(x=>`<div class="row"><span>${safe(x.exercise)}<small style="display:block">${safe(x.day)}</small></span><b class="num">${number(x.sets)} × ${number(x.reps)} · ${number(x.kg,1)} kg</b></div>`).join('')||'<div class="evo-empty">سجل التمرين الأول.</div>'}`)}
function updatesInfo(){g.open('✨ V0.06.1 — سجل التطور',`<div class="notice">The First Evolution · تحديث للوحة البيانات والإنجازات والتغذية والتمارين، مع المحافظة على سجلات النسخة السابقة.</div>${[
 ['📊','لوحة يومية مباشرة للسعرات والماء والنوم والدراسة والرياضة والمال والمواعيد'],
 ['🍽️','مؤشرات البروتين والكارب والدهون من سجل التغذية الفعلي'],
 ['⚖️','متابعة قياسات الوزن والفرق عن أول قياس'],
 ['🏋️','نموذج سريع لجولات المقاومة وتمارين النادي'],
 ['🏆','خمسة إنجازات دائمة بمكافآت XP غير مكررة'],
 ['🎯','أهداف يومية قابلة للتعديل دون تعديل السجلات القديمة'],
 ['🖥️','واجهة محسنة للويندوز مع تحديثات ومزامنة مؤشرات من داخل اللعبة'],
 ['🔄','تحديث عبر ملف منشور ومتحقق منه ببصمة SHA-256 وموافقة المستخدم']
 ].map(([ico,t])=>`<div class="row">${ico} ${safe(t)}</div>`).join('')}`)}
// Add a single panel below the existing game scene without replacing any legacy system.
function mount(){const stage=document.querySelector('.stats-strip');if(!stage)return;if(!document.getElementById('evo-mount')){const el=document.createElement('div');el.id='evo-mount';stage.insertAdjacentElement('afterend',el)}const nav=document.querySelector('#locations');if(nav&&!nav.querySelector('[data-action="evoAchievements"]'))nav.insertAdjacentHTML('beforeend','<button class="locbtn" data-action="evoAchievements">🏆 إنجازاتي</button>');render()}
function saveAndRefresh(){g.save();g.render();render()}
// Existing registered actions remain available; only these new actions are added.
Object.assign(window.glowExtraActions||{}, {evoAchievements:achievements,evoTargets:settingPage,evoWeight:weightPage,evoGym:gymPage,evoChangelog:updatesInfo});
document.addEventListener('click',e=>{const button=e.target.closest('[data-evo]');if(!button)return;const action=button.dataset.evo;
 ({food:()=>window.glowExtraActions?.fullFood?.(),weight:weightPage,gym:gymPage,study:()=>window.glowExtraActions?.study?.()||document.querySelector('[data-action="study"]')?.click(),achievements,targets:settingPage,changelog:updatesInfo})[action]?.();});
document.addEventListener('submit',e=>{const f=e.target;if(!['evo-targets','evo-weight','evo-gym'].includes(f.id))return;e.preventDefault();const data=Object.fromEntries(new FormData(f));const s=S();
 if(f.id==='evo-targets'){
  const limits={kcal:[500,10000],protein:[0,1000],carbs:[0,1500],fat:[0,500],weight:[20,300]};for(const [k,[min,max]]of Object.entries(limits))if(!valid(data[k],min,max))return g.toast('تحقق من حدود الأهداف');
  evo(s).targets=Object.fromEntries(Object.keys(limits).map(k=>[k,Number(data[k])]));saveAndRefresh();settingPage();g.toast('✓ حُفظت الأهداف');return;
 }
 s.expansion05??={};if(f.id==='evo-weight'){
  const kg=Number(data.kg),day=String(data.day||'');if(!valid(kg,20,400)||!/^\d{4}-\d\d-\d\d$/.test(day)||day>TODAY())return g.toast('تحقق من الوزن والتاريخ');
  s.expansion05.weight=arr(s.expansion05.weight);s.expansion05.weight.push({kg,day,id:crypto.randomUUID?.()||String(Date.now())});saveAndRefresh();weightPage();g.toast('✓ تم تسجيل الوزن');return;
 }
 if(f.id==='evo-gym'){
  const exercise=String(data.exercise||'').trim();const sets=Number(data.sets),reps=Number(data.reps),kg=Number(data.kg);
  if(exercise.length<2||exercise.length>80||!Number.isInteger(sets)||!valid(sets,1,30)||!Number.isInteger(reps)||!valid(reps,1,100)||!valid(kg,0,500))return g.toast('تحقق من بيانات التمرين');
  s.expansion05.gymSets=arr(s.expansion05.gymSets);s.expansion05.gymSets.push({exercise,sets,reps,kg,day:TODAY(),id:crypto.randomUUID?.()||String(Date.now())});saveAndRefresh();gymPage();g.toast('✓ تم تسجيل الجولات');return;
 }
});
window.addEventListener('glow:feeds',()=>render());
window.addEventListener('glow:changed',()=>{clearTimeout(render._timer);render._timer=setTimeout(()=>{checkAchievements();render()},70)});
mount();checkAchievements();setInterval(()=>{const t=document.querySelector('#evo-mount');if(t&&t.dataset.day!==TODAY()){t.dataset.day=TODAY();render();checkAchievements()}},60000);
})();
